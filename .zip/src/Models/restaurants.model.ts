export interface Restaurant{
    RestaurantID : number;
    restaurantName: string;
    rating: number;
}