export  interface OrderItem{
  orderItemID: number;
  name: string;
  customerID: number;
  orderID: number;
  itemID: number;
  quantity: number;
  price: number;
}